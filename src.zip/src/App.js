import logo from './logo.svg';
import './App.css';
import demo from './Component/demo';
import Showfile from './Component/Showfile';

function App() {
  return (
   <div>
    {/* <demo.js/> */}
    <Showfile/>
   </div>
  );
}

export default App;
